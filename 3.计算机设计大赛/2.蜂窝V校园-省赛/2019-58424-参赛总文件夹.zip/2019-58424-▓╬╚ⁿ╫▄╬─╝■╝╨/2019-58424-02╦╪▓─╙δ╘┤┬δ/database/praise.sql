/*
Navicat MySQL Data Transfer

Source Server         : 本地
Source Server Version : 50528
Source Host           : 127.0.0.1:3306
Source Database       : restful_crud

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2018-03-05 10:41:58
*/

alter table praise AUTO_INCREMENT=1;

-- SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for forumuser
-- ----------------------------
-- DROP TABLE IF EXISTS `praise`;
-- CREATE TABLE `praise` (
--   `idy` int(11) NOT NULL AUTO_INCREMENT,
--   `questionid` varchar(255) DEFAULT NULL,
--   `nickName` varchar(50) DEFAULT NULL,
--   `openid` varchar(50) DEFAULT NULL,
--   `pro1` varchar(50) DEFAULT NULL,
--   `pro2` varchar(50) DEFAULT NULL,
--   `pro3` varchar(50) DEFAULT NULL,
--   `pro4` varchar(50) DEFAULT NULL,
--   `pro5` varchar(50) DEFAULT NULL,
--   PRIMARY KEY (`idy`)
-- ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
