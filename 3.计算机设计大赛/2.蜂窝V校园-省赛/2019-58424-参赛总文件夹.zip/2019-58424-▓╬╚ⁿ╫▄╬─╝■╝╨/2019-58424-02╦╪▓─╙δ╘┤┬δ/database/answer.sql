/*
Navicat MySQL Data Transfer

Source Server         : 本地
Source Server Version : 50528
Source Host           : 127.0.0.1:3306
Source Database       : restful_crud

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2018-03-05 10:41:58
*/

alter table answer AUTO_INCREMENT=1;

-- SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for answer
-- ----------------------------
-- DROP TABLE IF EXISTS `answer`;
-- CREATE TABLE `answer` (
--   `ids` int(11) NOT NULL AUTO_INCREMENT,
--   `questionid` varchar(255) DEFAULT NULL,
--   `answercontent` varchar(255) DEFAULT NULL,
--   `element1` varchar(255) DEFAULT NULL,
--   `element2` varchar(255) DEFAULT NULL,
--   `element3` varchar(255) DEFAULT NULL,
--   `element4` varchar(255) DEFAULT NULL,
--   `element5` varchar(255) DEFAULT NULL,
--   `element6` varchar(255) DEFAULT NULL,
--   `element7` varchar(255) DEFAULT NULL,
--   `element8` varchar(255) DEFAULT NULL,
--   `element9` varchar(255) DEFAULT NULL,
--   `element10` varchar(255) DEFAULT NULL,
--   PRIMARY KEY (`ids`)
-- ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
